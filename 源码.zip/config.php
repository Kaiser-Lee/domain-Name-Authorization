<?php 
$host ="localhost";$port ="3306";$user ="sy_521sun_cn";$pwd = "86sHCaFQCaYhP7dd";$dbname = "sy_521sun_cn";?>